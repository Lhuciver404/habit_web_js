const express = require("express");
const session = require("express-session");
const bcrypt = require("bcrypt");
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
const DB_FILE = path.join(__dirname, "db.sqlite");
const db = new sqlite3.Database(DB_FILE);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.use(session({
  secret: "ganti_dengan_rahasia_kalian",
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000*60*60*24 } // 1 hari
}));

// init db
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
  );`);
  db.run(`CREATE TABLE IF NOT EXISTS todos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    text TEXT,
    done INTEGER DEFAULT 0,
    date TEXT
  );`);
  db.run(`CREATE TABLE IF NOT EXISTS habits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    name TEXT
  );`);
  db.run(`CREATE TABLE IF NOT EXISTS habit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    habit_id INTEGER,
    date TEXT
  );`);
  db.run(`CREATE TABLE IF NOT EXISTS sleep_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    date TEXT,
    sleep_time TEXT,
    wake_time TEXT
  );`);
});

// helper: auth middleware
function requireAuth(req, res, next) {
  if (req.session && req.session.userId) return next();
  res.status(401).json({ error: "unauthorized" });
}

// auth routes
app.post("/api/register", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: "missing" });
  const hash = await bcrypt.hash(password, 10);
  db.run(`INSERT INTO users(username,password) VALUES(?,?)`, [username, hash], function(err) {
    if (err) return res.status(400).json({ error: "username exists" });
    res.json({ ok: true });
  });
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  db.get(`SELECT * FROM users WHERE username = ?`, [username], async (err, user) => {
    if (err || !user) return res.status(400).json({ error: "invalid" });
    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(400).json({ error: "invalid" });
    req.session.userId = user.id;
    req.session.username = user.username;
    res.json({ ok: true });
  });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/api/me", (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  res.json({ user: { id: req.session.userId, username: req.session.username } });
});


// TODOs API
app.get("/api/todos", requireAuth, (req, res) => {
  const date = req.query.date || new Date().toISOString().slice(0,10);
  db.all(`SELECT * FROM todos WHERE user_id = ? AND date = ? ORDER BY id DESC`, [req.session.userId, date], (err, rows) => {
    res.json(rows || []);
  });
});

app.post("/api/todos", requireAuth, (req, res) => {
  const date = req.body.date || new Date().toISOString().slice(0,10);
  const text = req.body.text || "";
  db.run(`INSERT INTO todos(user_id,text,date) VALUES(?,?,?)`, [req.session.userId, text, date], function(err) {
    if (err) return res.status(500).json({ error: "db" });
    db.get(`SELECT * FROM todos WHERE id = ?`, [this.lastID], (e, row) => res.json(row));
  });
});

app.post("/api/todos/:id/done", requireAuth, (req, res) => {
  const id = req.params.id;
  db.run(`UPDATE todos SET done = 1 WHERE id = ? AND user_id = ?`, [id, req.session.userId], function(err) {
    if (err) return res.status(500).json({ error: "db" });
    res.json({ ok: true });
  });
});

// Habits
app.get("/api/habits", requireAuth, (req, res) => {
  db.all(`SELECT * FROM habits WHERE user_id = ?`, [req.session.userId], (err, rows) => res.json(rows || []));
});

app.post("/api/habits", requireAuth, (req, res) => {
  const name = req.body.name || "";
  db.run(`INSERT INTO habits(user_id,name) VALUES(?,?)`, [req.session.userId, name], function(err) {
    if (err) return res.status(500).json({ error: "db" });
    db.get(`SELECT * FROM habits WHERE id = ?`, [this.lastID], (e, row) => res.json(row));
  });
});

app.post("/api/habits/:id/done", requireAuth, (req, res) => {
  const habitId = req.params.id;
  const date = req.body.date || new Date().toISOString().slice(0,10);
  db.run(`INSERT INTO habit_logs(habit_id,date) VALUES(?,?)`, [habitId, date], function(err) {
    if (err) return res.status(500).json({ error: "db" });
    res.json({ ok: true });
  });
});

app.get("/api/habit_logs/:habitId/:date", requireAuth, (req, res) => {
  db.get(`SELECT 1 FROM habit_logs WHERE habit_id = ? AND date = ?`, [req.params.habitId, req.params.date], (err, row) => {
    res.json({ done: !!row });
  });
});

// Sleep logs
app.get("/api/sleep", requireAuth, (req, res) => {
  const limit = parseInt(req.query.limit||"7", 10);
  db.all(`SELECT date,sleep_time,wake_time FROM sleep_logs WHERE user_id = ? ORDER BY date DESC LIMIT ?`, [req.session.userId, limit], (err, rows) => {
    res.json(rows || []);
  });
});

app.post("/api/sleep", requireAuth, (req, res) => {
  const date = req.body.date || new Date().toISOString().slice(0,10);
  const sleep_time = req.body.sleep || "";
  const wake_time = req.body.wake || "";
  db.run(`INSERT INTO sleep_logs(user_id,date,sleep_time,wake_time) VALUES(?,?,?,?)`,
    [req.session.userId, date, sleep_time, wake_time], function(err) {
      if (err) return res.status(500).json({ error: "db" });
      res.json({ ok: true });
    });
});


// fallback: serve dashboard for / and let frontend handle auth
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "dashboard.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("Server jalan di http://localhost:" + PORT));
