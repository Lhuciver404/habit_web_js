async function api(path, opts={}) {
  opts.headers = opts.headers || {};
  if (!opts.headers['Content-Type']) opts.headers['Content-Type'] = 'application/json';
  const res = await fetch(path, opts);
  try { return await res.json(); } catch(e) { return {}; }
}

// init
(async function(){
  const me = await api("/api/me");
  if (!me.user) return window.location.href = "/login.html";
  document.getElementById("userInfo").innerText = "Hi, " + me.user.username;

  document.getElementById("logoutBtn").onclick = async () => {
    await api("/api/logout", { method: "POST" });
    location.href = "/login.html";
  };

  const today = new Date().toISOString().slice(0,10);

  // TODOS
  const todoForm = document.getElementById("todoForm");
  const todoList = document.getElementById("todoList");
  async function loadTodos(){
    const todos = await api("/api/todos?date=" + today);
    todoList.innerHTML = todos.map(t => `<li>${t.done? '✅' : `<button data-id="${t.id}" class="doneBtn">[ ]</button>`} ${escapeHtml(t.text)}</li>`).join("");
    document.querySelectorAll(".doneBtn").forEach(b=>{
      b.onclick = async e => {
        const id = e.target.dataset.id;
        await api("/api/todos/"+id+"/done", { method: "POST" });
        loadTodos();
      };
    });
  }
  todoForm.addEventListener("submit", async e=>{
    e.preventDefault();
    const text = document.getElementById("todoText").value.trim();
    if (!text) return;
    await api("/api/todos", { method: "POST", body: JSON.stringify({ text, date: today })});
    document.getElementById("todoText").value = "";
    loadTodos();
  });
  loadTodos();

  // HABITS
  const habitForm = document.getElementById("habitForm");
  const habitList = document.getElementById("habitList");
  async function loadHabits(){
    const habits = await api("/api/habits");
    habitList.innerHTML = "";
    for (const h of habits){
      const chkRes = await api(`/api/habit_logs/${h.id}/${today}`);
      const done = chkRes.done;
      const li = document.createElement("li");
      li.innerHTML = `${escapeHtml(h.name)} - ${done? '✅' : `<button class="habitBtn" data-id="${h.id}">Centang</button>`}`;
      habitList.appendChild(li);
    }
    document.querySelectorAll(".habitBtn").forEach(b=>{
      b.onclick = async e => {
        const id = e.target.dataset.id;
        await api(`/api/habits/${id}/done`, { method: "POST", body: JSON.stringify({ date: today })});
        loadHabits();
      };
    });
  }
  habitForm.addEventListener("submit", async e=>{
    e.preventDefault();
    const name = document.getElementById("habitName").value.trim();
    if (!name) return;
    await api("/api/habits", { method: "POST", body: JSON.stringify({ name })});
    document.getElementById("habitName").value = "";
    loadHabits();
  });
  loadHabits();

  // SLEEP + CHART
  const sleepForm = document.getElementById("sleepForm");
  const ctx = document.getElementById("sleepChart").getContext("2d");
  let chart;
  async function loadSleep(){
    const rows = await api("/api/sleep?limit=14");
    rows.reverse(); // oldest -> newest
    const labels = rows.map(r => r.date);
    // convert time string "hh:mm" to decimal hours for plotting
    const parseHour = s => s ? Number(s.split(":")[0]) + Number(s.split(":")[1]||0)/60 : null;
    const sleepData = rows.map(r => parseHour(r.sleep_time));
    const wakeData = rows.map(r => parseHour(r.wake_time));
    if (chart) chart.destroy();
    chart = new Chart(ctx, {
      type: "line",
      data: {
        labels,
        datasets: [
          { label: "Jam Tidur (jam)", data: sleepData, tension:0.3 },
          { label: "Jam Bangun (jam)", data: wakeData, tension:0.3 }
        ]
      },
      options: {
        scales: { y: { suggestedMin: 0, suggestedMax: 24 } }
      }
    });
  }

  sleepForm.addEventListener("submit", async e=>{
    e.preventDefault();
    const sleep = document.getElementById("sleepTime").value;
    const wake = document.getElementById("wakeTime").value;
    if (!sleep || !wake) return;
    await api("/api/sleep", { method: "POST", body: JSON.stringify({ date: today, sleep, wake })});
    document.getElementById("sleepTime").value = "";
    document.getElementById("wakeTime").value = "";
    loadSleep();
  });

  loadSleep();

})();

function escapeHtml(s){
  return s.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[m]);
}
